// p007.cpp
// ASCII codes

#include<iostream>

using namespace std;

int main()
{
    cout << "A\102\x43." <<  endl;
    cout << "This is another \
A\102\x43." <<  endl;
    return 0;
}
