// p009.cpp
// Boolean variables

#include<iostream>

using namespace std;

int main()
{
	int a=1;
	bool True=true;
	bool False=false;
    cout << "True= " << True << endl;
    cout << "False= " << False << endl;
    cout << "a= " << a << endl;
    cout << "a + (True==False) = " << a + (True==False) << endl;
    cout << "a + (False==0) = " << a + (False==0) << endl;
    return 0;
}
