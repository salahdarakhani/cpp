// p001.cpp
// The smallest program in C++.

int main()
{
}
