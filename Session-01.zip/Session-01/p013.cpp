// p013.cpp
// Default variables

#include<iostream>

using namespace std; 

int Divide(int a, int b=2) 
{
	int r;
	r= a / b; 
    return(r); 
} 

void WriteCodes(int a=0, int b=0, int c=0) 
{
	cout << a << b << c << endl;
} 

int main() 
{
	cout << "5/2= " << Divide(5,2) << endl;
	WriteCodes(); 
	WriteCodes(1); 
	WriteCodes(1, 2); 
	WriteCodes(1, 2, 3); 
    return 0; 
} 
