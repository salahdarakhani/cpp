// p002.cpp
// A simple program with an output line.

#include<iostream>

using namespace std;

int main()
{
    cout << "Welcome to C++ programming world!" << endl;
    return 0;
}
