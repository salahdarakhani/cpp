// p011.cpp
// Conditional operator

#include<iostream>

using namespace std;

int main()
{
	float a, b;
	cout << "Enter two numbers: ";
	cin >> a >>  b;
	cout << "The greatest one is: " << (a>b ? a : b) << endl;
    return 0;
}
