// p004.cpp
// Size of data types

#include<iostream>

using namespace std;

int main()
{
    int *p;
    cout << "Size of char: \t\t" << sizeof(char) << endl;
    cout << "Size of bool: \t\t" << sizeof(bool) << endl;
    cout << "Size of short int: \t" << sizeof(short int) << endl;
    cout << "Size of int: \t\t" << sizeof(int) << endl;
    cout << "Size of long int: \t" << sizeof(long int) << endl;
    cout << "Size of long long: \t" << sizeof(long long) << endl;
    cout << "Size of float: \t\t" << sizeof(float) << endl;
    cout << "Size of double: \t" << sizeof(double) << endl;
    cout << "Size of long double: \t" << sizeof(long double) << endl;
    cout << "Size of a pointer: \t" << sizeof(p) << endl;
    return 0;
}
