// p005.cpp
// Variables scope

#include<iostream>

using namespace std;

int a1=5;

int main()
{
	cout << "A1= " << a1 << endl;

	{
		int a2=10;
        cout << "A2= " << a2 << endl;
    }		
    cout << "A2= " << a2 << endl;    // Error!
	int a3=20;
    cout << "A3= " << a3 << endl;
    return 0;
}
