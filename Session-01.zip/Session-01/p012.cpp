// p012.cpp
// Loops

#include<iostream>

using namespace std;

int main()
{
	int i , j=10;
    while (j>0) {
		cout << j-- << endl;
		for(i=1;i<100*1000*1000*j;i++);
	}
    return 0;
}
