// p010.cpp
// Comma operator

#include<iostream>

using namespace std;

int main()
{
	int a, b, c;
	c= (a=5, b=a+2, 2*(a+b));
    cout << "a= " << a << endl;
    cout << "b= " << b << endl;
    cout << "c= " << c << endl;
    return 0;
}
