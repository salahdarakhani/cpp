// p003.cpp
// Input/Output

#include<iostream>

using namespace std;

int main()
{
    double Num1;
    cout << "Enter a number: ";
    cin >> Num1;
    cout << "The number you entered is: \"" << Num1 << "\"." << endl;
    return 0;
}
