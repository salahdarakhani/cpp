// p008.cpp
// constants with #define preprocessor

#include<iostream>

using namespace std;

#define A 12
#define NEWLINE "\n";

int main()
{
    cout << "A= " << A;
    cout << NEWLINE
    cout << "A= " << A;
    cout << "A= " << A;
    cout << NEWLINE
    cout << NEWLINE
    return 0;
}
