// p006.cpp
// Warning message from compiler

// Compile this program in these methods:
//     1. g++ -o p006.exe p006.cpp
//     2. g++ -Wall -o p006.exe p006.cpp

#include<iostream>

using namespace std;

int main()
{
	int a=1;
	int b(2);
	int c;
    cout << "(" << a << "," << b << "," << c << ")" << endl;
    return 0;
}
